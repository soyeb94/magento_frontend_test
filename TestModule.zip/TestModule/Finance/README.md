Hi.. This is my module for test...

Step 1: create folder code in app folder
	Exp : app/code

Step 2: Put the module folder (TestModule) in code folder
	Exp : magento/app/code/TestModule

	or
	
	Put the modue folder (TestModule) in vendor folder
	Exp : magento/vendor/TestModule


Step 3: Run the commands line following in your magento directory:

       php bin/magento setup:upgrade
       php bin/magento cache:flush

Step 4: Go to the Product page
	chekc the product with swatch options

Thank you


