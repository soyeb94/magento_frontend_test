<?php
/**
 * @category    TestModule
 * @package     TestModule_Finance
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'TestModule_Finance',
    __DIR__
);
